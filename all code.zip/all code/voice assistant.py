import pyttsx3
import datetime
import speech_recognition
import wikipedia
import webbrowser
import os
import random
import sys
import pywhatkit
import pyaudio
import pyjokes
import pyautogui
import requests
import bs4
import json
from googletrans import Translator
from time import sleep
from keyboard import write
from pyautogui import click
from wikipedia import search
