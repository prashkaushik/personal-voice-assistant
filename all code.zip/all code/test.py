import pyautogui
from time import sleep

sleep(8)
cs = pyautogui.position()
print(cs)