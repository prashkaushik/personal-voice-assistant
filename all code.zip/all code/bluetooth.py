import pyautogui
from time import sleep
from pyautogui import click
pyautogui.click(x=1640, y=1027)
sleep(1)
pyautogui.click(x=1659, y=381)
sleep(0.5)
pyautogui.click(x=1837, y=331)